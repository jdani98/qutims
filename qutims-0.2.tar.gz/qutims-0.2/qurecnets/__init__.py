# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 18:02:37 2023

@author: jdviqueira
"""

